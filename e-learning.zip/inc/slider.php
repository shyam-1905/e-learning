<div id="slider">
    <img src="images/slider/img1.jpg" alt="">
</div>