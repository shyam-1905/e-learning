<div id="top_course">
<h2>Top courses</h2>
<ul>
    <li>
        <a href="#">
            <img src="images/courses/img1.jpg">
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/courses/img1.jpg" alt="">
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/courses/img1.jpg" alt="">
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/courses/img1.jpg" >
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/courses/img1.jpg" >
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li>
    <li>
        <a href="">
            <img src="images/courses/img1.jpg" alt="">
            <h3>SOCIAL NETWORKING WEBSITE DEVELOPMENT IN PHP WITH PDO</h3>
            <h4>Price:$1234</h4>
            <h5>Teacher Name: shyam</h5>
        </a>
    </li><br clear="all"/>
</ul>
</div>



