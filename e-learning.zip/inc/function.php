<?php 
    function head_link() {
            include("inc/db.php");
            $get_link=$con->prepare("select * from contact");
            $get_link->setFetchMode(PDO:: FETCH_ASSOC);
            $get_link->execute();
            $row=$get_link->fetch();

            echo"<ul>
            <li><a href='htps://www.facebook.com/".$row['fb']."' target='blank'><i class='fab fa-facebook'></i></a></li>
            <li><a href='htps://www.twitter.com/".$row['tw']."' target='blank'''''''''''''''''''''><i class='fab fa-twitter'></i></a></li>
            <li><a href='htps://www.googleplus.com/".$row['gp']."' target='blank'><i class='fab fa-google-plus'></i></a></li>
            <li><a href='htps://www.youtube.com/".$row['yt']."' target='blank'><i class='fab fa-youtube'></i></a></li>
            <li><a href='htps://www.linkedin.com/".$row['link']."' target='blank'><i class='fab fa-linkedin'></i></a></li>
        </ul>";


}


function cat_menu(){
    include("inc/db.php");
    $get_cat=$con->prepare("select *from cat");
    $get_cat->setFetchMode(PDO:: FETCH_ASSOC);
    $get_cat->execute();
    while($row=$get_cat->fetch()):
        echo "<li>
         

        <a href=''> ".$row['cat_icon']." ".$row['cat_name']."</a></li>";
    endwhile;


}

function home_cat(){
    include("inc/db.php");
    $get_cat=$con->prepare("select *from cat");
    $get_cat->setFetchMode(PDO:: FETCH_ASSOC);
    $get_cat->execute();
    while($row=$get_cat->fetch()):
        echo "
        <li>
        <center>
                <a href=''>
                ".$row['cat_icon']."
                <h4>".$row['cat_name']."</h4>
                <p>2</p>
                </a>
            </center>
        </li>
        ";
    endwhile;

}
function cart() {
    include("inc/db.php");
    echo"<div id='wrap'>
    <div id='crumb'>
        <span><a href='index.php'>HOME</a></span>
        <span>MyCart</span>
    </div>
        <div id='cart'>
    
        </div><br clear='all'/>
    </div>";

}

?>