<div id="home_cat">
    <h2>Categories</h2>
    <ul>
        <?php
        echo home_cat();
        ?>
        <br clear="all" />
    </ul>
</div>
