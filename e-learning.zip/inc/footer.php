<div id="footer">
    <ul>
        <li>
            <h2><span>Abo</span>ut us</h2>
            <p>We Design A Perfect Logo For You To See Our Logos Just Visit Our Logo Page By Read More Button We Design A Perfect Logo For You To See Our Logos Just Visit Our Logo Page By Read More Button</p>
        </li>
        <li>
            <h2><span>Con</span>tact us</h2>
            <table>
                 <tr>
                    <td>
                    <i class="fas fa-map-marker-alt"></i>
                    </td>
                    <td>
                    sir padampat singhania university
                    </td>
                </tr>
                <tr>
                    <td>
                    <i class="fas fa-phone-square"></i>
                    </td>
                    <td>
                   +91xxxxxxxxxx
                    </td>
                </tr>
                <tr>
                    <td>
                    <i class="fas fa-envelope"></i>
                    </td>
                    <td>
                    shyam.reddy@spsu.ac.in
                    </td>
                </tr>
            </table>
            <div id="f_share">
                <div id="fb">
                 <a href="#"><i class="fab fa-facebook-f"></i></a>
                </div>
                <div id="gp">
                 <a href="#"><i class="fab fa-google-plus-g"></i></a>
                </div>
                <div id="tw">
                 <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
        <li>
            <h2><span>Lea</span>ve your Message</h2>
            <form method="post">
                <div id="f_input">
                <i class="fas fa-user"></i>
                <input type="text" name="query_name" placeholder="Enter your Name"/>
                </div>
                <div id="f_input">
                <i class="fas fa-envelope"></i>
                <input type="text" name="query_email" placeholder="Enter your email"/>
                </div>
                <textarea name="msg" placeholder="enter your message"></textarea> 
                <button>Send</button>
            </form>
        </li><br clear="all"/>
    </ul>
    <h3>All Right Reserve To INNOVATORS Copyright@2018 Innovators</h3>
</div>