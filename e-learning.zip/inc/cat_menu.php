<ul>
    <?php
    echo cat_menu();
    ?>
</ul>