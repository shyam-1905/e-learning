<div id='bodyright'>
	
	<h3>Contact Us</h3>
	<div id='con'>
	
			<?php echo Contact();?>
		
	</div>

</div>
