<?php include("inc/function.php");?>

<div id="header">
	
	<div id="logo">
		<h2><a href="index.php">PRK E-Learning</a></h2>
	</div>
	<div id="title">
		<h2>Admin panel of PRK E-Learning System</h2>
	</div>
	<div id="link">
		<h3><a href="#">Logout</a></h3>
	</div>
</div>
