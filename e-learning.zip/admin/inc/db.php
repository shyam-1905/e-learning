<?php
$con=new pdo("mysql:host=localhost;dbname=id14876344_e_learning","id14876344_shyam","!W%h?/>nJ?8AN9jh");
?>